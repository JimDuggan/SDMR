library(testthat)

test_check("pysd2r")
